
public class Student {
	
	private String rollNo;
	private String degree;
	private String semester;
	private String[] courseNum;
	private String[] courseName;
	private String[] courseSemester;
	private String[] grade;
	
	
	
	public String[] getGrade() {
		return grade;
	}
	public void setGrade(String[] grade) {
		this.grade = grade;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String[] getCourseNum() {
		return courseNum;
	}
	public void setCourseNum(String[] courseNum) {
		this.courseNum = courseNum;
	}
	public String[] getCourseName() {
		return courseName;
	}
	public void setCourseName(String[] courseName) {
		this.courseName = courseName;
	}
	public String[] getCourseSemester() {
		return courseSemester;
	}
	public void setCourseSemester(String[] courseSemester) {
		this.courseSemester = courseSemester;
	}
	
	
	

}
