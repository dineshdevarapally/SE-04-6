
public class University {
	private String universityName;
	private String universityAbb;
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public String getUniversityAbb() {
		return universityAbb;
	}
	public void setUniversityAbb(String universityAbb) {
		this.universityAbb = universityAbb;
	}
	
}
