
public class GradSchools {
	
	private String schoolName;
	private String schoolAbbr;
	
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public String getSchoolAbbr() {
		return schoolAbbr;
	}
	public void setSchoolAbbr(String schoolAbbr) {
		this.schoolAbbr = schoolAbbr;
	}
	
	

}
